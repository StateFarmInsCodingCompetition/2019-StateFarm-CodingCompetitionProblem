package codingcompetition2019;

public class DisasterDescription {
	// TODO finish this class
    private int year;
    private String category;
    private int reportedIncidentsNum;

    public DisasterDescription(){
        year = 0;
        category = "";
        reportedIncidentsNum = 0;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setReportedIncidentsNum(int reportedIncidentsNum) {
        this.reportedIncidentsNum = reportedIncidentsNum;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getReportedIncidentsNum() {
        return reportedIncidentsNum;
    }

    public String getYear() {
        String s = Integer.toString(year);
        return s;
    }

    public String getCategory() {
        return category;
    }
}
