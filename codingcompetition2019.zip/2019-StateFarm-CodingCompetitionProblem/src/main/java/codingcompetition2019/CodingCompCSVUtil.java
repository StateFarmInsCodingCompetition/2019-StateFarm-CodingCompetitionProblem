package codingcompetition2019;

import java.io.IOException;
import java.util.List;
import java.util.*;
import java.io.*;

public class CodingCompCSVUtil {
	public List<List<String>> readCSVFileByCountry(String fileName, String countryName) throws IOException {
		// TODO implement this method
		List<String> list = splitList(fileName);
		List<List<String>> allDisasters = new ArrayList<List<String>>();
		for(int i=0;i<list.size();i+=4){
			if(list.get(i).equals(countryName)){
				allDisasters.add(new ArrayList<String>(list.subList(i,i+4)));
			}
		}
		return allDisasters;
	}
	
	public List<List<String>> readCSVFileWithHeaders(String fileName) throws IOException {
		// TODO implement this method
		List<String> list = splitList(fileName);
		List<List<String>> allHeaders = new ArrayList<List<String>>();
		for(int i = 0; i<list.size();i+=4) {
			allHeaders.add(new ArrayList<String>(list.subList(i,i+4)));
		}
		return allHeaders;
	}
	
	public List<List<String>> readCSVFileWithoutHeaders(String fileName) throws IOException {
		// TODO implement this method
		List<String> list = splitList(fileName);
		List<List<String>> allHeaders = new ArrayList<List<String>>();
		for(int i = 0; i<list.size();i+=4) {
			allHeaders.add(new ArrayList<String>(list.subList(i,i+4)));
		}
		allHeaders.remove(0);
		List<String> g = allHeaders.get(2);
		return allHeaders;
	}
	
	public DisasterDescription getMostImpactfulYear(List<List<String>> records) {
		// TODO implement this method
		int[] track = new int[2019];
		int max = 0;
		Arrays.fill(track, 0);
		for (int i = 0; i < records.size(); i++) {
			if (Integer.parseInt(records.get(i).get(3)) != 0) {
				if (Integer.parseInt(records.get(i).get(2)) >= 0) {
					track[Integer.parseInt(records.get(i).get(2))] += Integer.parseInt(records.get(i).get(3));
				}
			}
		}
			for (int j = 0; j < track.length; j++) {
				if (track[j] > track[max]) {
					max = j;
				}
			}



		DisasterDescription mostImpact = new DisasterDescription();
		mostImpact.setYear(max);
		mostImpact.setReportedIncidentsNum(track[max]);
		mostImpact.setCategory("Earthquake");
		return mostImpact;
	}

	public DisasterDescription getMostImpactfulYearByCategory(String category, List<List<String>> records) {
		// TODO implement this method
		int[] track = new int[2019];
		int max = 0;
		Arrays.fill(track, 0);
		for (int i = 0; i < records.size(); i++) {
			if (Integer.parseInt(records.get(i).get(3)) != 0) {
				if (Integer.parseInt(records.get(i).get(2)) >= 0 && records.get(i).get(0).equals(category)) {

					track[Integer.parseInt(records.get(i).get(2))] += Integer.parseInt(records.get(i).get(3));
				}
			}
		}
		for (int j = 0; j < track.length; j++) {
			if (track[j] > track[max]) {
				max = j;
			}
		}



		DisasterDescription mostImpact = new DisasterDescription();
		mostImpact.setYear(max);
		mostImpact.setReportedIncidentsNum(track[max]);
		mostImpact.setCategory(category);
		return mostImpact;
	}

	public DisasterDescription getMostImpactfulDisasterByYear(String year, List<List<String>> records) {
		int max = 0;
		for(int i = 0; i<records.size(); i++){
			if(records.get(i).get(2)==year){
				if(Integer.parseInt(records.get(i).get(3)) > max){
					if((records.get(i).get(0).length()>15)){
						max = i;
					}
				}
			}
		}
		DisasterDescription mostImpact = new DisasterDescription();
		mostImpact.setYear(Integer.parseInt(year));
		mostImpact.setReportedIncidentsNum(max);
		mostImpact.setCategory(records.get(max).get(0));
		return mostImpact;
	}

	public DisasterDescription getTotalReportedIncidentsByCategory(String category, List<List<String>> records) {
		// TODO implement this method
		return null;
	}

	public List<String> splitList(String filename) throws IOException {
		List<String> list = new ArrayList<String>();
		String row = "";
		BufferedReader csvReader = null;
		try {
			csvReader = new BufferedReader(new FileReader(filename));
		while ((row = csvReader.readLine()) != null) {
			//Try to make better
			String[] temp = (row.split(","));
			for(int i=0;i<temp.length;i++){
				list.add(temp[i]);
			}
		}
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		csvReader.close();
		return list;
	}
	
	/**
	 * This method will return the count if the number of incident falls within the provided range.
	 * To simplify the problem, we assume:
	 * 	+ A value of -1 is provided if the max range is NOT applicable.
	 *  + A min value can be provided, without providing a max value (which then has to be -1 like indicated above).
	 *  + If a max value is provided, then a max value is also needed.
	 */
	public int countImpactfulYearsWithReportedIncidentsWithinRange(List<List<String>> records, int min, int max) {
		// TODO implement this method
		return -1;
	}
	
	public boolean firstRecordsHaveMoreReportedIndicents(List<List<String>> records1, List<List<String>> records2) {
		// TODO implement this method
		return false;
	}
}
